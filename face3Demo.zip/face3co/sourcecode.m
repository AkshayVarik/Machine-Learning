% 
% 3D FACE RECOGNITION SYSTEM
% 
% In order to obtain the complete source code for 3D Face Recognition System
% please visit my website
% 
% http://matlab-recognition-code.com/3d-face-recognition-biometric-system-matlab-full-source-code
% 
% For any question please email me hamdouchhd@hotmail.com
%
% Hamdi Boukamcha
% Sousse
% 4081
% Tunisia
% mobile +201650674269
% email hamdouchhd@hotmail.com
% website http://matlab-recognition-code.com
%
